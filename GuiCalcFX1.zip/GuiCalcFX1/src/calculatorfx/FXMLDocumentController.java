package calculatorfx;

import java.net.URL;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;

public class FXMLDocumentController implements Initializable{
		private static final int LIMIT = 15;
		Float firstOperand = 0f;
		Float secondOperand = 0f;
		int operation = -1;
		int operation2 = -1;
		Float ans = 0f;
		String pattern1 = "(\\d*.\\d*.\\d*)(\\D+)(\\d*.\\d*)";
		String pattern2 = "(\\D|.\\d*.\\d*)(\\D+)(\\d*.\\d*)([^0-9]$)";
		String pattern3 = "(\\D|.\\d*.?\\d*)(\\D+)(\\D|.\\d*.?\\d*)(.?$)";


//		final KeyCombination keyShiftTab = new KeyCodeCombination(KeyCode.MINUS, KeyCombination.SHIFT_ANY);



	 @FXML
	    private Button seven;

	    @FXML
	    private Button eight;

	    @FXML
	    private Button nine;

	    @FXML
	    private Button div;

	    @FXML
	    private Button four;

	    @FXML
	    private Button five;

	    @FXML
	    private Button six;

	    @FXML
	    private Button mult;

	    @FXML
	    private Button one;

	    @FXML
	    private Button two;

	    @FXML
	    private Button three;

	    @FXML
	    private Button minus;

	    @FXML
	    private Button zero;

	    @FXML
	    private Button clear;

	    @FXML
	    private Button equals;

	    @FXML
	    private Button plus;

	    @FXML
	    private Button point;

	    @FXML
	    private TextField display;


	    @FXML
	    public void handleButtonAction(ActionEvent event) {




	    	display.lengthProperty().addListener(new ChangeListener<Number>() {

	            @Override
	            public void changed(ObservableValue<? extends Number> observable,
	                    Number oldValue, Number newValue) {
	                if (newValue.intValue() > oldValue.intValue()) {
	                    // Check if the new character is greater than LIMIT
	                    if (display.getText().length() >= LIMIT) {
	                        // if it's 11th character then just setText to previous
	                        // one
	                        display.setText(display.getText().substring(0, LIMIT));
	                    }
	                }
	            }
	        });



/*		    display.addEventFilter(KeyEvent.KEY_PRESSED, new EventHandler<KeyEvent>()
			{
			@Override
			public void handle(KeyEvent e) {
				if(keyShiftTab.match(e)) {
					if(e.getSource() == equals) {
			    		Pattern p = Pattern.compile(pattern1);
			    		Matcher m = p.matcher(display.getText());

			    		while(m.find()) {
			    			firstOperand = Float.parseFloat(m.group(1));
			    			secondOperand = Float.parseFloat(m.group(3));
			    		}
			    		switch(operation)
			    		{
			    		case 1:
			    			ans = firstOperand - secondOperand;
			    			display.setText(String.valueOf(ans));
			    			break;
			    		case 2:
			    			ans = firstOperand + secondOperand;
			    			display.setText(String.valueOf(ans));
			    			break;
			    		case 3:
			    			ans = firstOperand * secondOperand;
			    			display.setText(String.valueOf(ans));
			    			break;
			    		case 4:
			    			try {
			    			ans = firstOperand / secondOperand;
			    			}catch(Exception a) {display.setText("Error");}
			    			display.setText(String.valueOf(ans));
			    			break;

			    		}
					}
					e.consume();
				}
			}

			});
*/
		    if(event.getSource() == one) {
	    		display.setText(display.getText() + "1");
	    	}else if(event.getSource() == two)  {
	    		display.setText(display.getText() + "2");
	    	}else if(event.getSource() == three){
	    		display.setText(display.getText() + "3");
	    	}else if(event.getSource() == four) {
	    		display.setText(display.getText() + "4");
	    	}else if(event.getSource() == five) {
	    		display.setText(display.getText() + "5");
	    	}else if(event.getSource() == six)  {
	    		display.setText(display.getText() + "6");
	    	}else if(event.getSource() == seven){
	    		display.setText(display.getText() + "7");
	    	}else if(event.getSource() == eight){
	    		display.setText(display.getText() + "8");
	    	}else if(event.getSource() == nine) {
	    		display.setText(display.getText() + "9");
	    	}else if(event.getSource() == zero) {
	    		display.setText(display.getText() + "0");
	    	}else if(event.getSource() == point) {
	    		display.setText(display.getText() + ".");
	    	}else if(event.getSource() == minus){
	    		operation = 1;
	    		display.setText(display.getText() + "-");
	    	}else if(event.getSource() == plus) {
	    		operation = 2;
	    		display.setText(display.getText() + "+");
	    	}else if(event.getSource() == mult) {
	    		operation = 3;
	    		display.setText(display.getText() + "*");
	    	}else if(event.getSource() == div) {
	    		operation = 4;
	    		display.setText(display.getText() + "/");
	    	}else if(event.getSource() == clear) {
	    		display.setText("");
	    		firstOperand = Float.parseFloat("0");
	    		secondOperand = Float.parseFloat("0");
	    	}else if(event.getSource() == equals) {
	    		Pattern p = Pattern.compile(pattern3);
	    		Matcher m = p.matcher(display.getText());

	    		while(m.find()) {
	    			firstOperand = Float.parseFloat(m.group(1));
	    			secondOperand = Float.parseFloat(m.group(3));
	    		}
	    		switch(operation)
	    		{
	    		case 1:
	    			ans = firstOperand - secondOperand;
	    			display.setText(String.valueOf(ans));
	    			break;
	    		case 2:
	    			ans = firstOperand + secondOperand;
	    			display.setText(String.valueOf(ans));
	    			break;
	    		case 3:
	    			ans = firstOperand * secondOperand;
	    			display.setText(String.valueOf(ans));
	    			break;
	    		case 4:
	    			try {
	    			ans = firstOperand / secondOperand;
	    			}catch(Exception e) {display.setText("Error");}
	    			display.setText(String.valueOf(ans));
	    			break;

	    		}
	    	}

	    	display.setOnKeyPressed(new EventHandler<KeyEvent>() {

		    	public void handle(KeyEvent event) {


		    		if(event.getCode() == KeyCode.MINUS) {
		    			operation = 1;
		    		}else if(event.getCode() == KeyCode.PLUS) {
		    			operation = 2;
		    		}else if(event.getCode() == KeyCode.ASTERISK) {
		    			operation = 3;
		    		}else if(event.getCode() == KeyCode.SLASH) {
		    			operation = 4;
		    		}

		    		if(event.getCode() == KeyCode.ENTER) {
		    	//	if(event.getCharacter() == "=") {
		    			String result = display.getText();


		    			switch(event.getCode()) {
		    	//		switch(event.getCharacter()) {
		    			case ENTER:

		    				Pattern p = Pattern.compile(pattern3);
		    	    		Matcher m = p.matcher(result);

		    	    		while(m.find()) {
		    	    			firstOperand = Float.parseFloat(m.group(1));
		    	    			secondOperand = Float.parseFloat(m.group(3));
		    	    			if(m.group(2).equals("-")) {
			    	    			operation=1;
			    	    		}else if(m.group(2).equals("+")){
			    	    			operation=2;
			    	    		}else if(m.group(2).equals("*")){
			    	    			operation=3;
			    	    		}else if(m.group(2).equals("/")){
			    	    			operation=4;
			    	    		}

		    	    	//		String operator = m.group(2);
		    	    		}

		    	    		switch(operation)
		    	    		{
		    	    		case 1:
		    	    			ans = firstOperand - secondOperand;
		    	    			display.setText(String.valueOf(ans));
		    	    			break;
		    	    		case 2:
		    	    			ans = firstOperand + secondOperand;
		    	    			display.setText(String.valueOf(ans));
		    	    			break;
		    	    		case 3:
		    	    			ans = firstOperand * secondOperand;
		    	    			display.setText(String.valueOf(ans));
		    	    			break;
		    	    		case 4:
		    	    			try {
		    	    			ans = firstOperand / secondOperand;
		    	    			}catch(Exception e) {display.setText("Error");}
		    	    			display.setText(String.valueOf(ans));
		    	    			break;
		    	    		}

	    				}
		    		}
		    	}
		    });
	    }

	@Override
	public void initialize(URL url, ResourceBundle rb) {


	}

}
